package com.cdac.DemoCURD;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoCurdApplicationTests {

	@Test
	void contextLoads() {
	}

}

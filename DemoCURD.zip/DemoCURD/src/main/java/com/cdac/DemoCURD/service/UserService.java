package com.cdac.DemoCURD.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cdac.DemoCURD.dao.UserRepository;
import com.cdac.DemoCURD.pojo.User;
@Service
public class UserService implements IUserService {
	@Autowired
	private UserRepository userRepo;

	@Override
	public User addUser(User user) {
		return userRepo.save(user);
	}

}

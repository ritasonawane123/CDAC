package com.cdac.DemoCURD.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cdac.DemoCURD.pojo.User;

public interface UserRepository extends JpaRepository<User, Integer> {

}

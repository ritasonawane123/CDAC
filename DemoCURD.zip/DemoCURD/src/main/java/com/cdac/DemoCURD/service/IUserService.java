package com.cdac.DemoCURD.service;

import com.cdac.DemoCURD.pojo.User;

public interface IUserService {
	User addUser(User user);
}
